async function loadStudents(){

const res = await fetch("/students");
const data = await res.json();

const list = document.getElementById("list");
list.innerHTML = "";

data.forEach(student=>{

list.innerHTML += `
<div class="card">
<div>
<b>${student.name}</b><br>
ID: ${student.id}<br>
Course: ${student.course}
</div>

<button class="delete"
onclick="deleteStudent(${student.id})">
Delete
</button>

</div>
`;

});

}

async function addStudent(){

const student={
id:Number(document.getElementById("id").value),
name:document.getElementById("name").value,
course:document.getElementById("course").value
};

await fetch("/students",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify(student)
});

loadStudents();

}

async function deleteStudent(id){

await fetch(`/students/${id}`,{
method:"DELETE"
});

loadStudents();

}

loadStudents();
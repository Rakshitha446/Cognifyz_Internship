const express = require("express");
const axios = require("axios");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const app = express();

app.use(cors());
app.use(express.static("public"));

// Rate Limiter
const limiter = rateLimit({
    windowMs: 60 * 1000,
    max: 10,
    message: "Too many requests. Try again later."
});

app.use(limiter);

// External API
app.get("/api/users", async (req, res) => {
    try {
        const response = await axios.get(
            "https://jsonplaceholder.typicode.com/users"
        );
        res.json(response.data);
    } catch (error) {
        res.status(500).json({
            message: "Error fetching API data"
        });
    }
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
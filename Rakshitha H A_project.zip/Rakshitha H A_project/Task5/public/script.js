async function loadUsers(){

const response = await fetch("/api/users");

const users = await response.json();

const output = document.getElementById("users");

output.innerHTML="";

users.forEach(user=>{

output.innerHTML += `
<div class="card">
<h3>${user.name}</h3>
<p>Email: ${user.email}</p>
<p>City: ${user.address.city}</p>
</div>
`;

});

}